1) Run 'forge-1.16.3-34.0.1-installer.jar'.
2) Select 'Install Client' and then 'OK'.
3) Open Minecraft and check there is a forge profile for 1.16.3. It should be called 'forge 1.16.3-forge-34.0.1'
4) Press WIN + R and paste in: 
%appdata%./minecraft
5) Delete everything in your mods folder and replace with the contents of the 'mods' folder in the ZIP.

Done!