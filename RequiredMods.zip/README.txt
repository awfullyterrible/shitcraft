1 - Run forge installer. Select 'install client' and click OK.
2 - Copy contents of 'mods' into your '.minecraft' folder.